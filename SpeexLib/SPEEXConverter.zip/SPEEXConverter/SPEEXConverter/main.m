//
//  main.m
//  SPEEXConverter
//
//  Created by Igor on 3/19/14.
//  Copyright (c) 2014 Igor. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SCAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SCAppDelegate class]));
    }
}
